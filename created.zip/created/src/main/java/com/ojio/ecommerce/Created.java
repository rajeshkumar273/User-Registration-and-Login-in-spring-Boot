package com.ojio.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Created {

	public static void main(String[] args) {
		SpringApplication.run(Created.class, args);
	}

}
